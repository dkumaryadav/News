package com.deepakyadav.newsgateway;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class FragmentsManager extends Fragment {

    private static final String TAG = "FragmentManager";

    TextView articleHeadLine;
    TextView articleDate;
    TextView articleAuthor;
    TextView articleText;
    ImageView articlePhoto;
    TextView articleCount;
    Article article;

    View view;
    public static final String ARTICLE = "ARTICLE";
    public static final String INDEX = "INDEX";
    public static final String TOTAL = "TOTAL";
    public static final String NOT_FOUND = "";
    public static final String DATE_PATTERN = "MMM dd, yyyy HH:mm";

    public static final FragmentsManager newFragment(Article article, int index, int total) {

        FragmentsManager fragment = new FragmentsManager();

        Bundle bundle = new Bundle(1);
        bundle.putSerializable(ARTICLE, article);
        bundle.putInt(INDEX, index);
        bundle.putInt(TOTAL, total);

        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        article = (Article) getArguments().getSerializable(ARTICLE);

        view = inflater.inflate(R.layout.fragment, container, false);
        articleHeadLine = (TextView) view.findViewById(R.id.articleHeadline);
        articleDate = (TextView) view.findViewById(R.id.articleDate);
        articleAuthor = (TextView) view.findViewById(R.id.articleAuthor);
        articleText = (TextView) view.findViewById(R.id.articleText);
        articleCount = (TextView) view.findViewById(R.id.articleCount);
        articlePhoto = (ImageView) view.findViewById(R.id.articleImage);

        articleCount.setText( (getArguments().getInt(INDEX)+1) + " of " + getArguments().getInt(TOTAL) );

        if(article.getArticleTitle() != null)
            articleHeadLine.setText(article.getArticleTitle());
        else
            articleHeadLine.setText(NOT_FOUND);

        if(article.getArticlePublishDate() !=null && !article.getArticlePublishDate().isEmpty()) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN);
                articleDate.setText( sdf.format( new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse( article.getArticlePublishDate() ) ) );
            } catch (ParseException e) {

            }
        }

        if(article.getArticleAuthor()!=null)
            articleAuthor.setText( article.getArticleAuthor());
        else
            articleAuthor.setText(NOT_FOUND);

        if( article.getArticleText() != null)
            articleText.setText( article.getArticleText() );
        else
            articleText.setText( NOT_FOUND );
        articleText.setMovementMethod(new ScrollingMovementMethod());

        if( article.getArticleImageURL()!=null )
            updateImage(article.getArticleImageURL() );

        articleHeadLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData( Uri.parse( article.getArticleURL()) );
                startActivity(intent);
            }
        });

        articleText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData( Uri.parse( article.getArticleURL()) );
                startActivity(intent);
            }
        });

        articleAuthor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData( Uri.parse( article.getArticleURL()) );
                startActivity(intent);
            }
        });


        articlePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData( Uri.parse( article.getArticleURL()) );
                startActivity(intent);
            }
        });

        return view;
    }

    private void updateImage(final String imageURL){

        Picasso picasso = new Picasso.Builder(getActivity()).listener(new Picasso.Listener() {
            @Override
            public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {

                final String changedUrl = imageURL.replace("http:", "https:");
                picasso.load(changedUrl)
                        .fit()
                        .centerCrop()
                        .error(R.drawable.brokenimage)
                        .placeholder(R.drawable.missing)
                        .into(articlePhoto);
            }
        }).build();
        picasso.load(imageURL)
                .fit()
                .centerCrop()
                .error(R.drawable.brokenimage)
                .placeholder(R.drawable.missing)
                .into(articlePhoto);
    }
}
