package com.deepakyadav.newsgateway;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    public static final String ACTION_SERVICE = "ACTION_SERVICE";
    public static final String ACTION_NEWS_STORY = "ACTION_NEWS_STORY";
    public static final String ARTICLE_LIST = "ARTICLE_LIST";
    public static final String SOURCE_ID = "SOURCE_ID";

    private DrawerLayout drawerLayout;
    private ListView drawerListView;
    private ActionBarDrawerToggle drawerToggle;
    private Adapter adapter;
    private Menu optionsMenu;

    private HashMap<String, Source> sourceStore = new HashMap<>();
    ArrayList<Drawer> drawerArrayList = new ArrayList<>();
    private ArrayList<String> sourceList = new ArrayList <>();
    private ArrayList<Source> sourceArrayList = new ArrayList <>();
    private ArrayList<String> categoryList = new ArrayList <>();
    private ArrayList<Article> articleArrayList = new ArrayList <>();
    private List <FragmentsManager> fragmentManagerList = new ArrayList<>();

    private boolean serviceStatus = false;
    private String newsSource;
    private NewsReceiver newsReceiver;
    private MyPageAdapter pageAdapter;
    private ViewPager viewPager;
    private int currentSourcePointer;
    String items[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Start service if not started
        if ( savedInstanceState == null && !serviceStatus ){
            Intent intent = new Intent(MainActivity.this, NewsService.class);
            startService(intent);
            serviceStatus = true;
        }

        newsReceiver = new NewsReceiver();
        IntentFilter filter = new IntentFilter(MainActivity.ACTION_NEWS_STORY);
        registerReceiver(newsReceiver, filter);

        drawerLayout = findViewById(R.id.drawerLayout);
        drawerListView = findViewById(R.id.drawerList);

        drawerListView.setOnItemClickListener(
                new ListView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        viewPager.setBackgroundResource(0);
                        currentSourcePointer = position;
                        selectItem(position);
                    }
                }
        );

        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open_nav, R.string.close_nav);

        adapter = new ColorsAdapter(this, drawerArrayList);
        drawerListView.setAdapter((ListAdapter) adapter);

        pageAdapter = new MyPageAdapter(getSupportFragmentManager());
       // pager = findViewById(R.id.viewPager);
       // pager.setAdapter(pageAdapter);

        if (sourceStore.isEmpty() && savedInstanceState == null )
            new SourceDownload(this, "").execute();

        if( getSupportActionBar() != null ){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }

    }

    private void selectItem(int position) {
        newsSource = sourceList.get(position);
        Intent intent = new Intent(MainActivity.ACTION_SERVICE);
        intent.putExtra(SOURCE_ID, newsSource);
        sendBroadcast(intent);
        drawerLayout.closeDrawer(drawerListView);
    }

    @Override
    public void onPostCreate(@Nullable Bundle savedInstanceState){
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }


    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (drawerToggle.onOptionsItemSelected(item)) {  // <== Important!
            Log.d(TAG, "onOptionsItemSelected: mDrawerToggle " + item);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.category_options, menu);
        optionsMenu = menu;
        optionsMenu.add("All");
        return super.onCreateOptionsMenu(menu);
    }

    public void initialiseSource(ArrayList<Source> arrayListSourceList, ArrayList<String> arrayListCategoryList)
    {
        sourceStore.clear();
        drawerArrayList.clear();
        sourceList.clear();
        sourceArrayList.clear();
        sourceArrayList.addAll(arrayListSourceList);

        for(int index = 0; index < sourceList.size(); index++){
            sourceList.add( arrayListSourceList.get(index).getSourceName());
            sourceStore.put( arrayListSourceList.get(index).getSourceName(), (Source)arrayListSourceList.get(index));
        }

        if(!optionsMenu.hasVisibleItems()) {
            categoryList.clear();
            categoryList =arrayListCategoryList;
            optionsMenu.add("All");
            Collections.sort(arrayListCategoryList);
            for (String categry : arrayListCategoryList)
                optionsMenu.add( categry );
        }

        for( Source s : arrayListSourceList ){

            Drawer drawerContent = new Drawer();
            drawerContent.setName(s.getSourceName());
            drawerArrayList.add( drawerContent );

            /*switch (s.getSourceCategory()){
                case "business":
                    drawerContent.setName(s.getSourceName());
                    drawerArrayList.add( drawerContent );
                    break;
                case "entertainment":
                    drawerContent.setName(s.getSourceName());
                    drawerArrayList.add(drawerContent);
                    break;
                case "sports":
                    drawerContent.setName(s.getSourceName());
                    drawerArrayList.add(drawerContent);
                    break;
                case "science":
                    drawerContent.setName(s.getSourceName());
                    drawerArrayList.add(drawerContent);
                    break;
                case "technology":
                    drawerContent.setName(s.getSourceName());
                    drawerArrayList.add(drawerContent);
                    break;
                case "general":
                    drawerContent.setName(s.getSourceName());
                    drawerArrayList.add(drawerContent);
                    break;
                case "health":
                    drawerContent.setName(s.getsName());
                    contentDrawers.add(drawerContent);
            }*/
        }
        // adapter.notifyDataSetChanged();
    }

    class NewsReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
                switch (intent.getAction()) {
                    case ACTION_NEWS_STORY:
                        ArrayList<Article> artList;
                        if (intent.hasExtra(ARTICLE_LIST)) {
                            artList = (ArrayList <Article>) intent.getSerializableExtra(ARTICLE_LIST);
                            ///reDoFragments(artList);
                        }
                        break;
                }
        }
    }

    private class MyPageAdapter extends FragmentPagerAdapter {
        private long baseId = 0;


        public MyPageAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getItemPosition(@NonNull Object object) {
            return POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentManagerList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentManagerList.size();
        }

        @Override
        public long getItemId(int position) {

            return baseId + position;
        }

        public void notifyChangeInPosition(int n) {
            baseId += getCount() + n;
        }


    }
}
